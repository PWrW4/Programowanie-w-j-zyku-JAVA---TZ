package lab01;

import javax.swing.*;

public class MonitorListModel extends AbstractListModel {
    @Override
    public int getSize() {
        return 0;
    }

    @Override
    public Object getElementAt(int index) {
        return null;
    }
}
