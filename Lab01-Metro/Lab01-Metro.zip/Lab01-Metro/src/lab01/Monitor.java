package lab01;

public class Monitor implements Runnable {

    @Override
    public void run() {

    }
}
